CREATE TABLE IF NOT EXISTS "Product" (
	"id"	INTEGER NOT NULL,
	"name"	TEXT NOT NULL,
	"manufacturer"	TEXT NOT NULL,
	"description"	TEXT NOT NULL,
	"colour"	TEXT NOT NULL,
	"weight"	INTEGER NOT NULL,
	"price"	NUMERIC NOT NULL,
	"quantity"	INTEGER NOT NULL,
	"isActive"	INTEGER NOT NULL,
	PRIMARY KEY("id" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "Category" (
	"id"	INTEGER NOT NULL,
	"name"	TEXT NOT NULL,
	"description"	TEXT NOT NULL,
	PRIMARY KEY("id" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "Address" (
	"id"	INTEGER NOT NULL,
	"street"	TEXT NOT NULL,
	"city"	TEXT NOT NULL,
	"postalcode"	TEXT NOT NULL,
	"country"	TEXT NOT NULL,
	PRIMARY KEY("id" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "User" (
	"id"	INTEGER NOT NULL,
	"fName"	TEXT NOT NULL,
	"lName"	TEXT NOT NULL,
	"phone"	TEXT NOT NULL,
	"email"	TEXT NOT NULL,
	"type"	INTEGER NOT NULL,
	"password"	TEXT NOT NULL,
	"dateOfCreation"	TEXT NOT NULL,
	"addressId"	INTEGER NOT NULL,
	FOREIGN KEY("addressId") REFERENCES "Address"("id"),
	PRIMARY KEY("id" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "Orders" (
	"id"	INTEGER NOT NULL,
	"dateOfCreation"	TEXT NOT NULL,
	"state"	TEXT NOT NULL,
	"totalPrice"	NUMERIC NOT NULL,
	"userId"	INTEGER NOT NULL,
	FOREIGN KEY("userId") REFERENCES "User"("id"),
	PRIMARY KEY("id" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "OrderItem" (
	"orderId"	INTEGER NOT NULL,
	"productId"	INTEGER NOT NULL,
	"quantity"	INTEGER NOT NULL,
	FOREIGN KEY("orderId") REFERENCES "Orders"("id"),
	FOREIGN KEY("productId") REFERENCES "Product"("id")
);
CREATE TABLE IF NOT EXISTS "ProductCategory" (
	"productId"	INTEGER NOT NULL,
	"categoryId"	INTEGER NOT NULL,
	FOREIGN KEY("productId") REFERENCES "Product"("id"),
	FOREIGN KEY("categoryId") REFERENCES "Category"("id")
);
