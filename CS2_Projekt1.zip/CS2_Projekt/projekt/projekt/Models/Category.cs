﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projekt.Models
{
    [Table(Name = "Category")]
    public class Category
    {
        [PrimaryKey(Skip = true)]
        public int id { get; set; }
        public string name { get; set; }
        public string description { get; set; }

        public override string ToString()
        {
            return name;
        }
        public async Task Insert()
        {
            await ORM.Insert(Database.GetInstance().connection, this);
        }
    }
}
