﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projekt.Models
{
    [Table(Name = "Product")]
    public class Product
    {
        [PrimaryKey(Skip = true)]
        public int id { get; set; }
        public string name { get; set; }
        public string manufacturer { get; set; }
        public string description { get; set; }
        public string colour { get; set; }
        public int weight { get; set; }
        public double price { get; set; }
        public int quantity { get; set; }
        public int isActive { get; set; }

        public async Task Insert()
        {
            await ORM.Insert(Database.GetInstance().connection, this);
        }

        public override string ToString()
        {
            return name;
        }
    }
}
