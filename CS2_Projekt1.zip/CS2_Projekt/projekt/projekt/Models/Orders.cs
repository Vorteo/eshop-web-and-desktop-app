﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projekt.Models
{
    [Table(Name = "Orders")]
    public class Orders
    {
        [PrimaryKey(Skip = true)]
        public int id { get; set; }
        public string dateOfCreation { get; set; }
        public string state { get; set; }
        public double totalPrice { get; set; }
        [ForeignKey]
        public int userId { get; set; }

        public async Task Insert()
        {
            await ORM.Insert(Database.GetInstance().connection, this);
        }
    }
}
