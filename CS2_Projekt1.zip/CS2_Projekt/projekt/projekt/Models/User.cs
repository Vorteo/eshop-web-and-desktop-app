﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace projekt.Models
{
    [Table(Name = "User")]
    public class User
    {
        [PrimaryKey(Skip = true)]
        public int id { get; set; }
        public string fName { get; set; }
        public string lName { get; set; }
        public string phone { get; set; }
        public string email { get; set; }
        public int type { get; set; }
        public string password { get; set; }
        public string dateOfCreation { get; set; }
        [ForeignKey]
        public int addressId { get; set; }

        public override string ToString()
        {
            return (fName + " " + lName);
        }
        public async Task Insert()
        {
            await ORM.Insert(Database.GetInstance().connection, this);
        }

        public async Task<bool> CheckLogin()
        {
            var user = await ORM.Select<User>(Database.GetInstance().connection, "SELECT * FROM User WHERE email = @0", this.email);

            if(user == null)
            {
                return false;
            }

            if (this.password == user[0].password)
            {
                this.password = user[0].password;
                this.phone = user[0].phone;
                this.id = user[0].id;
                this.email = user[0].email;
                this.fName = user[0].fName;
                this.lName = user[0].lName;
                this.type = user[0].type;
                this.addressId = user[0].addressId;
                this.dateOfCreation = user[0].dateOfCreation;

                return true;
            }

            return false;
        }

        public async Task<bool> CheckUser()
        {
            string regex = @"^[a-z0-9\.\-]+@[a-z0-9\.\-]+\.[a-z]{2,3}$";
            Regex reg = new Regex(regex, RegexOptions.IgnoreCase | RegexOptions.Compiled);

            /*
            string regex2 = @"^[0-9]{3}\-[0-9]{3}\-[0-9]{3}\-[0-9]{3}$";
            Regex reg1 = new Regex(regex2, RegexOptions.IgnoreCase | RegexOptions.Compiled);
            */

            if (!reg.IsMatch(email))
            {
                return false;
            }

            if (password.Length < 7)
            {
                return false;
            }
            else
            {
                int digit = 0, upper = 0;
                for (int c = 0; c < password.Length; c++)
                {
                    if (Char.IsDigit(password[c]))
                    {
                        digit++;
                    }
                    else if (Char.IsUpper(password[c]))
                    {
                        upper++;
                    }
                }

                if (digit < 2 || upper < 1)
                {
                    return false;
                } 
            }
            if (phone.Length != 15)
            {
                return false;
            }

            int space = 0;
            for(int i = 0; i < phone.Length; i++)
            {
                if(phone[i] == ' ')
                {
                    space++;
                }
            }

            if(space !=3)
            {
                return false;
            }

            var sameEmailUser = await ORM.Select<User>(Database.GetInstance().connection, "SELECT * FROM User WHERE email = @0", email);
            if (sameEmailUser != null)
            {
                return false;
            }

            return true;
        }
    }
}
