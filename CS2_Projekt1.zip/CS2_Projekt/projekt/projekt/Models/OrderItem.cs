﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projekt.Models
{
    [Table(Name = "OrderItem")]
    public class OrderItem
    {
        [ForeignKey]
        public int orderId { get; set; }
        [ForeignKey]
        public int productId { get; set; }
        public int quantity { get; set; }
        public string name { get; set; }

        public async Task Insert()
        {
            await ORM.Insert(Database.GetInstance().connection, this);
        }
    }
}
