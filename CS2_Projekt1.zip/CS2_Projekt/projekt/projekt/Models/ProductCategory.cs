﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projekt.Models
{
    [Table(Name = "ProductCategory")]
    public class ProductCategory
    {
        [ForeignKey]
        public int productId { get; set; }
        [ForeignKey]
        public int categoryId { get; set; }

        public async Task Insert()
        {
            await ORM.Insert(Database.GetInstance().connection, this);
        }
    }
}
