﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace projekt.Models
{
    [Table(Name = "Address")]
    public class Address
    {
        [PrimaryKey(Skip = true)]
        public int id { get; set; }
        public string street { get; set; }
        public string city { get; set; }
        public string postalCode { get; set; }
        public string country { get; set; }

        public async Task Insert()
        {
            await ORM.Insert(Database.GetInstance().connection, this);
        }

        internal bool Check()
        {
            if(postalCode.Length != 6)
            {
                return false;
            }
            for(int i = 0; i < postalCode.Length; i++)
            {
                if(postalCode[i] == ' ')
                {
                    continue;
                }
                else if(!Char.IsDigit(postalCode[i]))
                {
                    return false;
                }
            }
            return true;
        }
    }
}
