﻿using projekt.Forms;
using projekt.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projekt
{
    public partial class Form1 : Form
    {
        public static User loggedUser = null;

        public Form1()
        {
            InitializeComponent();
            Init();
        }

        private async void Init()
        {
            await Database.GetInstance().Connect();
        }

        private async void Exit(object sender, EventArgs e)
        {
            await Database.GetInstance().Close();
            this.Close();
            Application.Exit();
        }

        private async void Login(object sender, EventArgs e)
        {
            if(this.textBox1.Text == "")
            {
                MessageBox.Show("You have to fill your password!");
                textBox1.Focus();
                return;
            }
            if(this.textBox2.Text == "")
            {
                MessageBox.Show("You have to fill your email!");
                textBox2.Focus();
                return;
            }

            string password = textBox1.Text;
            string email = textBox2.Text;

            User user = new User()
            {
                email = email,
                password = password,
            };

            if(await user.CheckLogin())
            {
                MessageBox.Show("Successful login");
                loggedUser = user;
                this.Hide();
                MenuForm menuForm = new MenuForm();
                menuForm.Show();
                return;
            }
            else
            {
                MessageBox.Show("Login failed");
                return;
            }
        }
    }
}
