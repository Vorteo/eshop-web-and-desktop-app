﻿using projekt.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projekt.Forms
{
    public partial class UsersForm : Form
    {
        BindingList<User> bindingList = new BindingList<User>();
        string keyword = null;
        int type;

        public UsersForm()
        {
            InitializeComponent();
            Init();

            if(Form1.loggedUser.type == 3)
            {
                createBtn.Enabled = false;
            }
        }
        private async void Init()
        {
            List<User> userList = await ORM.Select<User>(Database.GetInstance().connection, "SELECT * FROM User", new object[0]);
            bindingList.Clear();

            foreach(User user in userList)
            {
                bindingList.Add(user);
            }

            this.usersDataGrid.AutoGenerateColumns = false;
            this.usersDataGrid.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "First Name",
                DataPropertyName = nameof(User.fName)
            });

            this.usersDataGrid.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Last Name",
                DataPropertyName = nameof(User.lName)
            });

            this.usersDataGrid.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Email",
                DataPropertyName = nameof(User.email)
            });

            this.usersDataGrid.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Phone",
                DataPropertyName = nameof(User.phone)
            });

            this.usersDataGrid.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Type",
                DataPropertyName = nameof(User.type)
            });

            this.usersDataGrid.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Date Of Creation",
                DataPropertyName = nameof(User.dateOfCreation)
            });

            this.usersDataGrid.Columns.Add(new DataGridViewButtonColumn()
            {
                UseColumnTextForButtonValue = true,
                HeaderText = "",
                Text = "Edit",
                Name = "edit"
            });

            BindingSource binding = new BindingSource();
            binding.DataSource = bindingList;
            this.usersDataGrid.DataSource = binding;
        }

        private async void Refresh(int type = 0, string keyword = "")
        {
            List<User> userList = await ORM.Select<User>(Database.GetInstance().connection, "SELECT * FROM User", new object[0]);
            Collection<User> users = new Collection<User>();

            foreach(User u in userList)
            {
                if(keyword != null)
                {
                    string name = u.fName + " " + u.lName;
                    if((type == 0) && (name.Contains(keyword)))
                    {
                        users.Add(u);
                    }
                    else if ((type == u.type) && (name.Contains(keyword)))
                    {
                        users.Add(u);
                    }
                }
                else
                {
                    if(type == 0)
                    {
                        users.Add(u);
                    }
                    else if(type == u.type)
                    {
                        users.Add(u);
                    }
                }
            }

            bindingList.Clear();
            bindingList = new BindingList<User>(users);
            usersDataGrid.DataSource = bindingList;
        }

        private void Back(object sender, EventArgs e)
        {
            this.Hide();
            MenuForm menuForm = new MenuForm();
            menuForm.Show();
        }

        private void Create(object sender, EventArgs e)
        {
            CreateUserForm createUserForm = new CreateUserForm();
            createUserForm.ShowDialog();
            Refresh();
        }

        private void Show(object sender, EventArgs e)
        {
            if(textBox1.Text  == "")
            {
                keyword = null;
            }
            else
            {
                keyword = textBox1.Text;
            }

            if(allRadioBtn.Checked)
            {
                type = 0;
            }
            else if(adminRadioBtn.Checked)
            {
                type = 1;
            }
            else if(employeRadioBtn.Checked)
            {
                type = 2;
            }
            else if(customerRadioBtn.Checked)
            {
                type = 3;
            }

            Refresh(type, keyword);
        }

        private void usersDataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridView datagrid = sender as DataGridView;

            User user = bindingList[e.RowIndex];
            if (datagrid.Columns[e.ColumnIndex].Name == "edit")
            {
                if (Form1.loggedUser.type != 3)
                {
                    EditUserForm editUserForm = new EditUserForm(user);
                    editUserForm.ShowDialog();
                }
                Refresh();
            }
        }
    }
}
