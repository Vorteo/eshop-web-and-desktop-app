﻿using projekt.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projekt.Forms
{
    public partial class ProfileForm : Form
    {
        BindingList<Orders> bindingList = new BindingList<Orders>();
        public ProfileForm()
        {
            InitializeComponent();
            Init();

        }
        private async void Init()
        {
            fNameInput.Text = Form1.loggedUser.fName;
            lNameInput.Text = Form1.loggedUser.lName;
            emailInput.Text = Form1.loggedUser.email;
            phoneInput.Text = Form1.loggedUser.phone;

            Address address = (await ORM.Select<Address>(Database.GetInstance().connection, "SELECT * FROM Address WHERE id = @0", Form1.loggedUser.addressId))[0];

            streetInput.Text = address.street;
            cityInput.Text = address.city;
            postalCodeInput.Text = address.postalCode;
            countryInput.Text = address.country;

            List<Orders> orderList = await ORM.Select<Orders>(Database.GetInstance().connection,"SELECT * FROM Orders WHERE userId = @0", Form1.loggedUser.id);
            bindingList.Clear();

            foreach(Orders o in orderList)
            {
                bindingList.Add(o);
            }

            this.dataGridView1.AutoGenerateColumns = false;

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Order Number",
                DataPropertyName = nameof(Orders.id)
            });
            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Date Of Creation",
                DataPropertyName = nameof(Orders.dateOfCreation)
            });

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "State",
                DataPropertyName = nameof(Orders.state)
            });

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Total Price",
                DataPropertyName = nameof(Orders.totalPrice)
            });

            BindingSource binding = new BindingSource();
            binding.DataSource = bindingList;
            this.dataGridView1.DataSource = bindingList;

        }

        private void BackHome(object sender, EventArgs e)
        {
            this.Hide();
            MenuForm menuForm = new MenuForm();
            menuForm.Show();
        }
    }
}
