﻿using projekt.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projekt.Forms
{
    public partial class OrdersForm : Form
    {
        int keyword;
        BindingList<Orders> bindingList = new BindingList<Orders>();
        public OrdersForm()
        {
            InitializeComponent();
            Init();
        }
        private async void Init()
        {
            List<Orders> ordersList = await ORM.Select<Orders>(Database.GetInstance().connection, "SELECT * FROM Orders", new object[0]);
            bindingList.Clear();

            foreach(Orders order in ordersList)
            {
                bindingList.Add(order);
            }

            this.ordersDataGrid.AutoGenerateColumns = false;
            ordersDataGrid.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Order Number",
                DataPropertyName = nameof(Orders.id)
            });

            ordersDataGrid.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Date Of Creation",
                DataPropertyName = nameof(Orders.dateOfCreation)
            });

            ordersDataGrid.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "State",
                DataPropertyName = nameof(Orders.state)
            });

            ordersDataGrid.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Total Price",
                DataPropertyName = nameof(Orders.totalPrice)
            });

            ordersDataGrid.Columns.Add(new DataGridViewButtonColumn()
            {
                UseColumnTextForButtonValue = true,
                HeaderText = "",
                Text = "Edit",
                Name = "edit"
            });

            ordersDataGrid.Columns.Add(new DataGridViewButtonColumn()
            {
                UseColumnTextForButtonValue = true,
                HeaderText = "",
                Text = "Delete",
                Name = "delete"
            });
    
            BindingSource binding = new BindingSource();
            binding.DataSource = bindingList;
            this.ordersDataGrid.DataSource = binding;

        }
        private async void Refresh1(int? keyword=0)
        {
            List<Orders> orderList = await ORM.Select<Orders>(Database.GetInstance().connection, "SELECT * FROM Orders", new object[0]);

            Collection<Orders> orders = new Collection<Orders>();

            foreach(var order in orderList)
            {
                if(keyword != 0)
                {
                    if(keyword == order.id)
                    {
                        orders.Add(order);
                    }
                }
                else
                {
                    orders.Add(order);
                }
            }

            bindingList.Clear();
            bindingList = new BindingList<Orders>(orders);
            ordersDataGrid.DataSource = bindingList;


        }

        private void ordersDataGrid_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            for(int i = 0; i < bindingList.Count; i++)
            {
                if(bindingList[i].state == "Cancelled")
                {
                    ordersDataGrid.Rows[i].Cells["delete"] = new DataGridViewTextBoxCell()
                    {
                        Value = "Cannot be deleted"
                    };

                }
            }
        }

        private async void ordersDataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridView datagrid = sender as DataGridView;

            Orders order = bindingList[e.RowIndex];
            if(datagrid.Columns[e.ColumnIndex].Name == "delete")
            {
                if(datagrid.Rows[e.RowIndex].Cells["delete"] is DataGridViewButtonCell)
                {
                    order.state = "Cancelled";
                    await ORM.Update(Database.GetInstance().connection,order);
                    
                }
            }
            else if(datagrid.Columns[e.ColumnIndex].Name == "edit")
            {
                EditOrderForm editOrderForm = new EditOrderForm(order);
                editOrderForm.ShowDialog();
                        
            }
            Refresh1();
        }

        private void Back(object sender, EventArgs e)
        {
            Hide();
            MenuForm menuForm = new MenuForm();
            menuForm.Show();
        }

        private void CreateOrder(object sender, EventArgs e)
        {
            CreateOrderForm createOrderForm = new CreateOrderForm();
            createOrderForm.ShowDialog();
            Refresh1();
        }

        private void Search(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                keyword = 0;
            }
            else
            {
                keyword = Convert.ToInt32(textBox1.Text);
            }
            Refresh1(keyword);
        }

       
    }
}
