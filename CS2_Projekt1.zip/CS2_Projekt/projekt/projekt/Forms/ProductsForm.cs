﻿using projekt.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projekt.Forms
{
    public partial class ProductsForm : Form
    {
        private static BindingList<Product> products = new BindingList<Product>();
        public ProductsForm()
        {
            InitializeComponent();
            Init();

            if(Form1.loggedUser.type == 3)
            {
                addProductBtn.Enabled = false;
                button1.Enabled = false;
            }
         
        }
        public async void Init()
        {
            List<Product> productsList = await ORM.Select<Product>(Database.GetInstance().connection, "SELECT * FROM Product", new object[0]);

            products.Clear();
            
            foreach(Product p in productsList)
            {
                products.Add(p);
            }
            

            this.productsGridView.AutoGenerateColumns = false;
            this.productsGridView.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Name",
                DataPropertyName = nameof(Product.name)
            });

            this.productsGridView.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Manufacturer",
                DataPropertyName = nameof(Product.manufacturer)
            });

            this.productsGridView.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Description",
                DataPropertyName = nameof(Product.description)
            });

            this.productsGridView.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Colour",
                DataPropertyName = nameof(Product.colour)
            });

            this.productsGridView.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Weight",
                DataPropertyName = nameof(Product.weight)
            });

            this.productsGridView.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Price",
                DataPropertyName = nameof(Product.price)
            });

            this.productsGridView.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Quantity",
                DataPropertyName = nameof(Product.quantity)
            });

            this.productsGridView.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Is Active",
                DataPropertyName = nameof(Product.isActive)
            });

            this.productsGridView.Columns.Add(new DataGridViewButtonColumn()
            {
                UseColumnTextForButtonValue = true,
                HeaderText = "",
                Text = "Edit",
                Name = "edit"
            });

            this.productsGridView.Columns.Add(new DataGridViewButtonColumn()
            {
                UseColumnTextForButtonValue = true,
                HeaderText = "",
                Text = "Disable",
                Name = "disable"
            });

            BindingSource binding = new BindingSource();
            binding.DataSource = products;
            this.productsGridView.DataSource = binding;

        }

        private void Back(object sender, EventArgs e)
        {
            this.Hide();
            MenuForm menuform = new MenuForm();
            menuform.Show();
        }

        private void AddProduct(object sender, EventArgs e)
        {
            CreateProductForm createProductForm = new CreateProductForm();
            createProductForm.ShowDialog();
            Refresh1();
        }

        private void productsGridView_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            for(int i = 0; i < products.Count; i++)
            {
                if(products[i].isActive == 0)
                {
                    productsGridView.Rows[i].Cells["disable"] = new DataGridViewTextBoxCell()
                    {
                        Value = "Disabled"
                    };
                }
            }
        }

        private async void productsGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (Form1.loggedUser.type == 1 || Form1.loggedUser.type == 2)
            {
                DataGridView dataGrid = sender as DataGridView;

                Product p = products[e.RowIndex];
                if (dataGrid.Columns[e.ColumnIndex].Name == "disable")
                {
                    if (dataGrid.Rows[e.RowIndex].Cells["disable"] is DataGridViewButtonCell)
                    {
                        p.isActive = 0;
                        int update = await ORM.Update(Database.GetInstance().connection, p);
                    }
                }
                else if (dataGrid.Columns[e.ColumnIndex].Name == "edit")
                {   
                    EditProductForm editProductForm = new EditProductForm(p);
                    editProductForm.ShowDialog();
                }
                Refresh1();
            }
        }
        private async void Refresh1()
        {
            List<Product> userList = await ORM.Select<Product>(Database.GetInstance().connection, "SELECT * FROM Product", new object[0]);
            products.Clear();
            products = new BindingList<Product>(userList);
            productsGridView.DataSource = products;
        }

        private void Restock(object sender, EventArgs e)
        {
            AddQuantityForm addQuantityForm = new AddQuantityForm();
            addQuantityForm.ShowDialog();
            Refresh1();
        }
    }
}
