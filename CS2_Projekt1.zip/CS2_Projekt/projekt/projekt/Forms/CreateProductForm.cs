﻿using projekt.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projekt.Forms
{
    public partial class CreateProductForm : Form
    {
        public CreateProductForm()
        {
            InitializeComponent();
            Init();
            
        }  
        private async void Init()
        {
            List<Category> categories = await ORM.Select<Category>(Database.GetInstance().connection, "SELECT * FROM Category", new object[0]);
            Collection<Category> collection = new Collection<Category>(categories);

            foreach (var c in collection)
            {              
                comboBox1.Items.Add(c);
            }        
        }

        private void Cancel(object sender, EventArgs e)
        {
            this.Hide();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            if (nameInput.Text != "" && manufacturerInput.Text != "" && richTextBox1.Text != "" && colorInput.Text != "" && quantityInput.Text != "" &&
            weightInput.Text != "" && priceInput.Text != "")
            {
                Product product = new Product()
                {
                    name = nameInput.Text,
                    manufacturer = manufacturerInput.Text,
                    description = richTextBox1.Text,
                    colour = colorInput.Text,
                    isActive = 1,
                };

                if (comboBox1.SelectedIndex < 0)
                {
                    MessageBox.Show("Please choose category!", "Category Alert", MessageBoxButtons.OK);
                    return;
                }

                Category category = comboBox1.SelectedItem as Category;

                if (!Int32.TryParse(weightInput.Text, out int weight))
                {
                    MessageBox.Show("You have to write number", "input", MessageBoxButtons.OK);
                    return;
                }
                product.weight = weight;

                if (!Int32.TryParse(priceInput.Text, out int price))
                {
                    MessageBox.Show("You have to write number", "input", MessageBoxButtons.OK);
                    return;
                }
                product.price = price;

                if (!Int32.TryParse(quantityInput.Text, out int quantity))
                {
                    MessageBox.Show("You have to write number", "input", MessageBoxButtons.OK);
                    return;
                }
                product.quantity = quantity;

                await product.Insert();

                ProductCategory productCategory = new ProductCategory()
                {
                    productId = product.id,
                    categoryId = category.id
                };

                await productCategory.Insert();
                MessageBox.Show("Product successfully added", "Success", MessageBoxButtons.OK);
                Hide();
            }
        }
    }

}
