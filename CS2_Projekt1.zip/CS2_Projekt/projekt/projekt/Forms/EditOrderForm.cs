﻿using projekt.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projekt.Forms
{
    public partial class EditOrderForm : Form
    {
        User user = new User();
        Address address = new Address();
        Orders orders = new Orders();
        BindingList<OrderItem> bindinglist = new BindingList<OrderItem>();

        public EditOrderForm(Orders o)
        {
            orders = o;
            InitializeComponent();
            Init();
            if(o.state == "Paid")
            {
                paybtn.Enabled = false;
            }
        }
        private async void Init()
        {
            user = (await ORM.Select<User>(Database.GetInstance().connection, "SELECT * FROM User WHERE id = @0", orders.userId))[0];
            address = (await ORM.Select<Address>(Database.GetInstance().connection, "SELECT * FROM Address WHERE id = @0", user.id))[0];

            streetbox.Text = address.street;
            citybox.Text = address.city;
            pscbox.Text = address.postalCode;
            countrybox.Text = address.country;

            namebox.Text = user.fName;
            lastnamebox.Text = user.lName;
            mailbox.Text = user.email;
            phonebox.Text = user.phone;

            List<Product> products = await ORM.Select<Product>(Database.GetInstance().connection, "SELECT * FROM Product", new object[0]);
            foreach(var p in products)
            {
                comboBox1.Items.Add(p);
            }
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;

            dataGridView1.AutoGenerateColumns = false;

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Name",
                DataPropertyName = nameof(OrderItem.name)
            });

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Quantity",
                DataPropertyName = nameof(OrderItem.quantity)
            });

            dataGridView1.Columns.Add(new DataGridViewButtonColumn()
            {
                UseColumnTextForButtonValue = true,
                Text = "-",
                Name = "decrement"
            });
          
            List<OrderItem> oItems = await ORM.Select<OrderItem>(Database.GetInstance().connection, "SELECT * FROM OrderItem WHERE orderId = @0", orders.id);  

            foreach(var o in oItems)
            {
                bindinglist.Add(o);
            }
            dataGridView1.DataSource = bindinglist;
        }

        private async void Save(object sender, EventArgs e)
        {
            if (namebox.Text != "" && lastnamebox.Text != "" && phonebox.Text != "" && mailbox.Text != "" && streetbox.Text != "" && citybox.Text != "" && pscbox.Text != "" && countrybox.Text != "")
            {
                address.street = streetbox.Text;
                address.city = citybox.Text;
                address.postalCode = pscbox.Text;
                address.country = countrybox.Text;

                await ORM.Update(Database.GetInstance().connection, address);

                user.fName = namebox.Text;
                user.lName = lastnamebox.Text;
                user.phone = phonebox.Text;
                user.email = mailbox.Text;
                user.dateOfCreation = DateTime.Now.ToString();

                await ORM.Update(Database.GetInstance().connection, user);

                List<OrderItem> orderI = await ORM.Select<OrderItem>(Database.GetInstance().connection, "SELECT * FROM OrderItem WHERE orderId = @0", orders.id);

                foreach (var o in orderI)
                {
                    foreach (Product p in comboBox1.Items)
                    {
                        if (o.productId == p.id)
                        {
                            p.quantity += o.quantity;
                            await ORM.Update(Database.GetInstance().connection, p);
                            await ORM.Delete(Database.GetInstance().connection, o);
                        }
                    }
                }

                orderI.Clear();

                double totalPrice = 0;

                foreach (var b in bindinglist)
                {
                    orderI.Add(b);
                    foreach (Product c in comboBox1.Items)
                    {
                        if (c.id == b.productId)
                        {
                            totalPrice += (c.price * b.quantity);
                            c.quantity -= b.quantity;
                            await ORM.Update(Database.GetInstance().connection, c);
                        }
                    }
                }

                if (bindinglist.Count <= 0)
                {
                    await ORM.Delete(Database.GetInstance().connection, orders);
                }
                else
                {
                    orders.totalPrice = totalPrice;
                    await ORM.Update(Database.GetInstance().connection, orders);
                    foreach (var b in bindinglist)
                    {
                        b.orderId = orders.id;
                        await ORM.Insert(Database.GetInstance().connection, b);
                    }
                }
                this.Hide();
            }
            dataGridView1.Refresh();
        }

        private void AddProduct(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex >= 0)
            {
                Product p = comboBox1.SelectedItem as Product;
                OrderItem orderItem = new OrderItem()
                {
                    name = p.name,
                    productId = p.id,
                    quantity = 1
                };
                bool exists = false;
                foreach (var b in bindinglist)
                {
                    if (b.productId == orderItem.productId)
                    {
                        exists = true;
                        b.quantity += 1;
                    }
                }
                if (exists == false)
                {
                    bindinglist.Add(orderItem);
                }

                dataGridView1.Refresh();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridView datagrid = sender as DataGridView;

            OrderItem oItem = bindinglist[e.RowIndex];
            if (datagrid.Columns[e.ColumnIndex].Name == "decrement")
            {
                if (datagrid.Rows[e.RowIndex].Cells["decrement"] is DataGridViewButtonCell)
                {
                    bindinglist[e.RowIndex].quantity--;
                    if (bindinglist[e.RowIndex].quantity <= 0)
                    {
                        bindinglist.Remove(oItem);
                    }
                    dataGridView1.Refresh();
                }
            }
        }

        private void dataGridView1_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            for (int i = 0; i < bindinglist.Count; i++)
            {
                if (bindinglist[i].quantity < 1)
                {
                    dataGridView1.Rows[i].Cells["decrement"] = new DataGridViewTextBoxCell()
                    {
                        Value = ""
                    };
                }
            }
        }

        private async void Pay(object sender, EventArgs e)
        {
            if (orders.state != "Paid")
            {
                orders.state = "Paid";
                await ORM.Update(Database.GetInstance().connection, orders);
            }  
        }
    }
}
