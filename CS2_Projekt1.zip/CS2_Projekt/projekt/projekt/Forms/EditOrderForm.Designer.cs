﻿namespace projekt.Forms
{
    partial class EditOrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pscbox = new System.Windows.Forms.TextBox();
            this.citybox = new System.Windows.Forms.TextBox();
            this.streetbox = new System.Windows.Forms.TextBox();
            this.mailbox = new System.Windows.Forms.TextBox();
            this.phonebox = new System.Windows.Forms.TextBox();
            this.namebox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.addProductBtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.saveBtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.countrybox = new System.Windows.Forms.TextBox();
            this.paybtn = new System.Windows.Forms.Button();
            this.lastnamebox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pscbox
            // 
            this.pscbox.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.pscbox.Location = new System.Drawing.Point(46, 431);
            this.pscbox.Name = "pscbox";
            this.pscbox.PlaceholderText = "Postal Code";
            this.pscbox.Size = new System.Drawing.Size(110, 25);
            this.pscbox.TabIndex = 41;
            // 
            // citybox
            // 
            this.citybox.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.citybox.Location = new System.Drawing.Point(46, 402);
            this.citybox.Name = "citybox";
            this.citybox.PlaceholderText = "City";
            this.citybox.Size = new System.Drawing.Size(142, 25);
            this.citybox.TabIndex = 40;
            // 
            // streetbox
            // 
            this.streetbox.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.streetbox.Location = new System.Drawing.Point(46, 373);
            this.streetbox.Name = "streetbox";
            this.streetbox.PlaceholderText = "Street";
            this.streetbox.Size = new System.Drawing.Size(161, 25);
            this.streetbox.TabIndex = 39;
            // 
            // mailbox
            // 
            this.mailbox.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.mailbox.Location = new System.Drawing.Point(46, 344);
            this.mailbox.Name = "mailbox";
            this.mailbox.PlaceholderText = "Email";
            this.mailbox.Size = new System.Drawing.Size(201, 25);
            this.mailbox.TabIndex = 38;
            // 
            // phonebox
            // 
            this.phonebox.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.phonebox.Location = new System.Drawing.Point(46, 315);
            this.phonebox.Name = "phonebox";
            this.phonebox.PlaceholderText = "Phone Number";
            this.phonebox.Size = new System.Drawing.Size(142, 25);
            this.phonebox.TabIndex = 37;
            // 
            // namebox
            // 
            this.namebox.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.namebox.Location = new System.Drawing.Point(46, 286);
            this.namebox.Name = "namebox";
            this.namebox.PlaceholderText = "First Name";
            this.namebox.Size = new System.Drawing.Size(127, 25);
            this.namebox.TabIndex = 36;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(31, 253);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 21);
            this.label1.TabIndex = 35;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(292, 219);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(145, 25);
            this.comboBox1.TabIndex = 34;
            // 
            // addProductBtn
            // 
            this.addProductBtn.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.addProductBtn.Location = new System.Drawing.Point(443, 218);
            this.addProductBtn.Name = "addProductBtn";
            this.addProductBtn.Size = new System.Drawing.Size(109, 29);
            this.addProductBtn.TabIndex = 33;
            this.addProductBtn.Text = "Add";
            this.addProductBtn.UseVisualStyleBackColor = true;
            this.addProductBtn.Click += new System.EventHandler(this.AddProduct);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(31, 36);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.Size = new System.Drawing.Size(521, 176);
            this.dataGridView1.TabIndex = 32;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dataGridView1_DataBindingComplete);
            // 
            // saveBtn
            // 
            this.saveBtn.BackColor = System.Drawing.SystemColors.ControlLight;
            this.saveBtn.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.saveBtn.Location = new System.Drawing.Point(384, 541);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(168, 46);
            this.saveBtn.TabIndex = 31;
            this.saveBtn.Text = "Save";
            this.saveBtn.UseVisualStyleBackColor = false;
            this.saveBtn.Click += new System.EventHandler(this.Save);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.countrybox);
            this.groupBox1.Controls.Add(this.paybtn);
            this.groupBox1.Controls.Add(this.lastnamebox);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(37, 253);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(515, 268);
            this.groupBox1.TabIndex = 42;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Personal Details";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(9, 235);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 19);
            this.label2.TabIndex = 44;
            this.label2.Text = "Make Payment";
            // 
            // countrybox
            // 
            this.countrybox.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.countrybox.Location = new System.Drawing.Point(152, 178);
            this.countrybox.Name = "countrybox";
            this.countrybox.PlaceholderText = "Country";
            this.countrybox.Size = new System.Drawing.Size(139, 25);
            this.countrybox.TabIndex = 28;
            // 
            // paybtn
            // 
            this.paybtn.Location = new System.Drawing.Point(116, 225);
            this.paybtn.Name = "paybtn";
            this.paybtn.Size = new System.Drawing.Size(118, 37);
            this.paybtn.TabIndex = 43;
            this.paybtn.Text = "Pay";
            this.paybtn.UseVisualStyleBackColor = true;
            this.paybtn.Click += new System.EventHandler(this.Pay);
            // 
            // lastnamebox
            // 
            this.lastnamebox.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lastnamebox.Location = new System.Drawing.Point(142, 33);
            this.lastnamebox.Name = "lastnamebox";
            this.lastnamebox.PlaceholderText = "Last Name";
            this.lastnamebox.Size = new System.Drawing.Size(139, 25);
            this.lastnamebox.TabIndex = 22;
            // 
            // EditOrderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(589, 596);
            this.Controls.Add(this.pscbox);
            this.Controls.Add(this.citybox);
            this.Controls.Add(this.streetbox);
            this.Controls.Add(this.mailbox);
            this.Controls.Add(this.phonebox);
            this.Controls.Add(this.namebox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.addProductBtn);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.saveBtn);
            this.Controls.Add(this.groupBox1);
            this.Name = "EditOrderForm";
            this.Text = "Edit Order";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox pscbox;
        private System.Windows.Forms.TextBox citybox;
        private System.Windows.Forms.TextBox streetbox;
        private System.Windows.Forms.TextBox mailbox;
        private System.Windows.Forms.TextBox phonebox;
        private System.Windows.Forms.TextBox namebox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button addProductBtn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button saveBtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox countrybox;
        private System.Windows.Forms.TextBox lastnamebox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button paybtn;
    }
}