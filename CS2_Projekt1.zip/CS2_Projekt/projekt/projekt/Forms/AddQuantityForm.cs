﻿using projekt.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projekt.Forms
{
    public partial class AddQuantityForm : Form
    {
        public AddQuantityForm()
        {
            InitializeComponent();
            Init();

        }
        private async void Init()
        {
            List<Product> products = await ORM.Select<Product>(Database.GetInstance().connection, "SELECT * FROM Product", new object[0]);

            foreach(var p in products)
            {
                comboBox1.Items.Add(p);
            }
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private async void AddQuantity(object sender, EventArgs e)
        {
            if(textBox1.Text != "")
            {
                if(!Int32.TryParse(textBox1.Text, out int quantity))
                {
                    MessageBox.Show("Enter number.");
                    return;
                }
                if(comboBox1.SelectedIndex >= 0)
                {
                    Product product = comboBox1.SelectedItem as Product;
                    product.quantity += quantity;

                    await ORM.Update(Database.GetInstance().connection, product);
                    MessageBox.Show("Restock successfully finished");
                    Hide();
                }
            }
        }
    }
}
