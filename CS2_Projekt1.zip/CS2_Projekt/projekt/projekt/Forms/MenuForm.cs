﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projekt.Forms
{
    public partial class MenuForm : Form
    {
        public MenuForm()
        {
            InitializeComponent();
            if (Form1.loggedUser.type == 3)
            {
                UsersBtn.Enabled = false;
                ordersBtn.Enabled = false;
            }
        }

        private async void Exit(object sender, EventArgs e)
        {
            await Database.GetInstance().Close();
            this.Close();
            Application.Exit();
        }

        private void ShowProfile(object sender, EventArgs e)
        {
            this.Hide();
            ProfileForm profileForm = new ProfileForm();
            profileForm.ShowDialog();
        }

        private void ShowProducts(object sender, EventArgs e)
        {
            this.Hide();
            ProductsForm productsForm = new ProductsForm();
            productsForm.Show();
        }

        private void ShowUsers(object sender, EventArgs e)
        {
                this.Hide();
                UsersForm usersForm = new UsersForm();
                usersForm.Show();
        }

        private void ShowOrders(object sender, EventArgs e)
        {
          
                this.Hide();
                OrdersForm ordersForm = new OrdersForm();
                ordersForm.Show();
        }
    }
}
