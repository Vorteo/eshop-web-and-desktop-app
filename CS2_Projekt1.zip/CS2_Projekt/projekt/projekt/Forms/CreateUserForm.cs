﻿using projekt.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace projekt.Forms
{
    public partial class CreateUserForm : Form
    {
        public CreateUserForm()
        {
            InitializeComponent();
        }

        private async void Create(object sender, EventArgs e)
        {
            string regex = @"^[a-z0-9\.\-]+@[a-z0-9\.\-]+\.[a-z]{2,3}$";
            Regex reg = new Regex(regex, RegexOptions.IgnoreCase | RegexOptions.Compiled);

            if (fname.Text != "" && lname.Text != "" && password.Text != "" && phone.Text != "" && email.Text != "" && street.Text != "" && city.Text != "" && psc.Text != "" && country.Text != "")
            {
                User user = new User()
                {
                    fName = fname.Text,
                    lName = lname.Text,
                    email = email.Text,
                    phone = phone.Text,
                    password = password.Text,
                    dateOfCreation = DateTime.Now.ToString(),
                };

                if(comboBox1.SelectedIndex >= 0)
                {
                    user.type = comboBox1.SelectedIndex +1;
                }

                bool cantCreate = await user.CheckUser();

                if (cantCreate)
                {
                    Address address = new Address()
                    {
                        street = street.Text,
                        city = city.Text,
                        postalCode = psc.Text,
                        country = country.Text,
                    };

                    bool addr = address.Check();
                    if (addr)
                    {
                        await address.Insert();
                        user.addressId = (int)address.id;
                        await user.Insert();

                        MessageBox.Show("User successfully created.");
                        this.Hide();
                        return;
                    }
                }
                
            }

            MessageBox.Show("Cannot create new User.");
        }
    }
}
