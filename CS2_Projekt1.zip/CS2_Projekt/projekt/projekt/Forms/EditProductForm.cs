﻿using projekt.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projekt.Forms
{
    public partial class EditProductForm : Form
    {
        Product product = new Product();
        public EditProductForm(Product p)
        {
            product = p;
            InitializeComponent();

            nameInput.Text = product.name;
            manufacturerInput.Text = product.manufacturer;
            richTextBox1.Text = product.description;
            colorInput.Text = product.colour;
            quantityInput.Text = product.quantity.ToString();
            weightInput.Text = product.weight.ToString();
            priceInput.Text = product.price.ToString();

            int active = product.isActive;
            if(active == 0)
            {
                noRadioBtn.Checked = true;
            }
            else if(active == 1)
            {
                yesRadioBtn.Checked = true;
            }
            
        }

        private async void Save(object sender, EventArgs e)
        {
            if (nameInput.Text != "" && manufacturerInput.Text != "" && richTextBox1.Text != "" && colorInput.Text != "" && quantityInput.Text != "" &&
            weightInput.Text != "" && priceInput.Text != "")
            {
                if (!Int32.TryParse(weightInput.Text, out int weight))
                {
                    MessageBox.Show("You have to write number", "input", MessageBoxButtons.OK);
                    return;
                }
                product.weight = weight;

                if (!Int32.TryParse(priceInput.Text, out int price))
                {
                    MessageBox.Show("You have to write number", "input", MessageBoxButtons.OK);
                    return;
                }
                product.price = price;

                if (!Int32.TryParse(quantityInput.Text, out int quantity))
                {
                    MessageBox.Show("You have to write number", "input", MessageBoxButtons.OK);
                    return;
                }
                product.quantity = quantity;

                product.name = nameInput.Text;
                product.manufacturer = manufacturerInput.Text;
                product.colour = colorInput.Text;
                product.description = richTextBox1.Text;

                if(yesRadioBtn.Checked)
                {
                    product.isActive = 1;
                }
                else if(noRadioBtn.Checked)
                {
                    product.isActive = 0;
                }

                await ORM.Update(Database.GetInstance().connection, product);
                this.Hide();
            }
        }
    }
}
