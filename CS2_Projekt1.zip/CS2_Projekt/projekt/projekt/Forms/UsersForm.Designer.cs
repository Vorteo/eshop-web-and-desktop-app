﻿namespace projekt.Forms
{
    partial class UsersForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backBtn = new System.Windows.Forms.Button();
            this.createBtn = new System.Windows.Forms.Button();
            this.usersDataGrid = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.showBtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.allRadioBtn = new System.Windows.Forms.RadioButton();
            this.adminRadioBtn = new System.Windows.Forms.RadioButton();
            this.employeRadioBtn = new System.Windows.Forms.RadioButton();
            this.customerRadioBtn = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.usersDataGrid)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // backBtn
            // 
            this.backBtn.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.backBtn.Location = new System.Drawing.Point(12, 12);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(121, 29);
            this.backBtn.TabIndex = 1;
            this.backBtn.Text = "Back";
            this.backBtn.UseVisualStyleBackColor = true;
            this.backBtn.Click += new System.EventHandler(this.Back);
            // 
            // createBtn
            // 
            this.createBtn.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.createBtn.Location = new System.Drawing.Point(12, 73);
            this.createBtn.Name = "createBtn";
            this.createBtn.Size = new System.Drawing.Size(121, 41);
            this.createBtn.TabIndex = 3;
            this.createBtn.Text = "Create New User";
            this.createBtn.UseVisualStyleBackColor = true;
            this.createBtn.Click += new System.EventHandler(this.Create);
            // 
            // usersDataGrid
            // 
            this.usersDataGrid.AllowUserToAddRows = false;
            this.usersDataGrid.AllowUserToDeleteRows = false;
            this.usersDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.usersDataGrid.BackgroundColor = System.Drawing.SystemColors.Control;
            this.usersDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.usersDataGrid.Location = new System.Drawing.Point(12, 120);
            this.usersDataGrid.Name = "usersDataGrid";
            this.usersDataGrid.ReadOnly = true;
            this.usersDataGrid.RowHeadersVisible = false;
            this.usersDataGrid.RowTemplate.Height = 25;
            this.usersDataGrid.ShowEditingIcon = false;
            this.usersDataGrid.Size = new System.Drawing.Size(776, 318);
            this.usersDataGrid.TabIndex = 4;
            this.usersDataGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.usersDataGrid_CellContentClick);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox1.Location = new System.Drawing.Point(522, 50);
            this.textBox1.Name = "textBox1";
            this.textBox1.PlaceholderText = "Search by Name";
            this.textBox1.Size = new System.Drawing.Size(266, 25);
            this.textBox1.TabIndex = 7;
            // 
            // showBtn
            // 
            this.showBtn.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.showBtn.Location = new System.Drawing.Point(522, 83);
            this.showBtn.Name = "showBtn";
            this.showBtn.Size = new System.Drawing.Size(266, 31);
            this.showBtn.TabIndex = 8;
            this.showBtn.Text = "Show";
            this.showBtn.UseVisualStyleBackColor = true;
            this.showBtn.Click += new System.EventHandler(this.Show);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.allRadioBtn);
            this.groupBox1.Controls.Add(this.adminRadioBtn);
            this.groupBox1.Controls.Add(this.employeRadioBtn);
            this.groupBox1.Controls.Add(this.customerRadioBtn);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(330, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(186, 77);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Users";
            // 
            // allRadioBtn
            // 
            this.allRadioBtn.AutoSize = true;
            this.allRadioBtn.Checked = true;
            this.allRadioBtn.Location = new System.Drawing.Point(7, 23);
            this.allRadioBtn.Name = "allRadioBtn";
            this.allRadioBtn.Size = new System.Drawing.Size(42, 23);
            this.allRadioBtn.TabIndex = 3;
            this.allRadioBtn.TabStop = true;
            this.allRadioBtn.Text = "All";
            this.allRadioBtn.UseVisualStyleBackColor = true;
            // 
            // adminRadioBtn
            // 
            this.adminRadioBtn.AutoSize = true;
            this.adminRadioBtn.Location = new System.Drawing.Point(92, 23);
            this.adminRadioBtn.Name = "adminRadioBtn";
            this.adminRadioBtn.Size = new System.Drawing.Size(67, 23);
            this.adminRadioBtn.TabIndex = 2;
            this.adminRadioBtn.Text = "Admin";
            this.adminRadioBtn.UseVisualStyleBackColor = true;
            // 
            // employeRadioBtn
            // 
            this.employeRadioBtn.AutoSize = true;
            this.employeRadioBtn.Location = new System.Drawing.Point(7, 48);
            this.employeRadioBtn.Name = "employeRadioBtn";
            this.employeRadioBtn.Size = new System.Drawing.Size(79, 23);
            this.employeRadioBtn.TabIndex = 1;
            this.employeRadioBtn.Text = "Employe";
            this.employeRadioBtn.UseVisualStyleBackColor = true;
            // 
            // customerRadioBtn
            // 
            this.customerRadioBtn.AutoSize = true;
            this.customerRadioBtn.Location = new System.Drawing.Point(92, 48);
            this.customerRadioBtn.Name = "customerRadioBtn";
            this.customerRadioBtn.Size = new System.Drawing.Size(87, 23);
            this.customerRadioBtn.TabIndex = 0;
            this.customerRadioBtn.Text = "Customer";
            this.customerRadioBtn.UseVisualStyleBackColor = true;
            // 
            // UsersForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.showBtn);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.usersDataGrid);
            this.Controls.Add(this.createBtn);
            this.Controls.Add(this.backBtn);
            this.Name = "UsersForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UsersForm";
            ((System.ComponentModel.ISupportInitialize)(this.usersDataGrid)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.Button createBtn;
        private System.Windows.Forms.DataGridView usersDataGrid;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button showBtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton allRadioBtn;
        private System.Windows.Forms.RadioButton adminRadioBtn;
        private System.Windows.Forms.RadioButton employeRadioBtn;
        private System.Windows.Forms.RadioButton customerRadioBtn;
    }
}