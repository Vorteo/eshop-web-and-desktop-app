﻿using projekt.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projekt.Forms
{
    public partial class CreateOrderForm : Form
    {
        BindingList<OrderItem> bindinglist = new BindingList<OrderItem>();
        public CreateOrderForm()
        {
            InitializeComponent();
            Init();
        }
        private async void Init()
        {
            List<Product> products = await ORM.Select<Product>(Database.GetInstance().connection, "SELECT * FROM Product", new object[0]);
            foreach(Product product in products)
            {
                if (product.isActive == 1)
                {
                    comboBox1.Items.Add(product);
                }
            }

            List<User> users = await ORM.Select<User>(Database.GetInstance().connection, "SELECT * FROM User", new object[0]);
            foreach(User user in users)
            {
                comboBox2.Items.Add(user);
            }    

            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;

            dataGridView1.AutoGenerateColumns = false;

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Name",
                DataPropertyName = nameof(OrderItem.name)
            });

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Quantity",
                DataPropertyName = nameof(OrderItem.quantity)
            });

            dataGridView1.Columns.Add(new DataGridViewButtonColumn()
            {
                UseColumnTextForButtonValue = true,
                Text = "-",
                Name = "decrement"
            });

            dataGridView1.DataSource = bindinglist;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridView datagrid = sender as DataGridView;

            OrderItem oItem = bindinglist[e.RowIndex];
            if(datagrid.Columns[e.ColumnIndex].Name == "decrement")
            {
                if(datagrid.Rows[e.RowIndex].Cells["decrement"] is DataGridViewButtonCell)
                {
                    bindinglist[e.RowIndex].quantity--;
                    if(bindinglist[e.RowIndex].quantity <= 0)
                    {
                        bindinglist.Remove(oItem);
                    }
                    dataGridView1.Refresh();
                }
            }
        }

        private void dataGridView1_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            for(int i=0; i<bindinglist.Count; i++)
            {
                if(bindinglist[i].quantity < 1)
                {
                    dataGridView1.Rows[i].Cells["decrement"] = new DataGridViewTextBoxCell()
                    {
                        Value = ""
                    };
                }
            }
        }

        private void AddProduct(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex >= 0)
            {
                Product p = comboBox1.SelectedItem as Product;

                OrderItem orderItem = new OrderItem()
                {
                    name = p.name,
                    productId = p.id,
                    quantity = 1
                };

                bool exists = false;
                foreach(var b in bindinglist)
                {
                    if(b.productId == orderItem.productId)
                    {
                        exists = true;
                        b.quantity += 1;
                    }
                }
                if(exists == false)
                {
                    bindinglist.Add(orderItem);
                }

                dataGridView1.Refresh();
            }
        }

        private async void CreateOrder(object sender, EventArgs e)
        {
            Address address = new Address();
            User user = new User();

            if (comboBox2.SelectedIndex >= 0)
            {
                user = comboBox2.SelectedItem as User;
                address = (await ORM.Select<Address>(Database.GetInstance().connection, "SELECT * FROM Address WHERE id = @0", user.addressId))[0];
            }
            else
            {
                if (namebox.Text != "" && lastnamebox.Text != "" && phonebox.Text != "" && mailbox.Text != "" && streetbox.Text != "" && citybox.Text != "" && pscbox.Text != "" && countrybox.Text != "")
                {
                    address.street = streetbox.Text;
                    address.city = citybox.Text;
                    address.postalCode = pscbox.Text;
                    address.country = countrybox.Text;

                    await address.Insert();

                    user.fName = namebox.Text;
                    user.lName = lastnamebox.Text;
                    user.phone = phonebox.Text;
                    user.email = mailbox.Text;
                    user.type = 3;
                    user.dateOfCreation = DateTime.Now.ToString();
                    user.password = "GuEsT2022";
                    user.addressId = address.id;

                    await user.Insert();
                }
                else
                {
                    MessageBox.Show("Cannot create order");
                    return;
                }
            }

            Orders order = new Orders()
            {
                dateOfCreation = DateTime.Now.ToString(),
                state = "Accepted",
                totalPrice = 0,
                userId = user.id,
            };

            List<OrderItem> orderItems = new List<OrderItem>();

            bool result = checkProductsCapacity();

            if(result)
            {
                foreach (var b in bindinglist)
                {
                    orderItems.Add(b);
                    foreach (Product c in comboBox1.Items)
                    {
                        if (c.id == b.productId)
                        {
                            order.totalPrice += (c.price * b.quantity);
                            c.quantity -= b.quantity;
                            await ORM.Update(Database.GetInstance().connection, c);
                        }                   
                    }
                }

                await ORM.Insert(Database.GetInstance().connection, order);
                foreach (var b in bindinglist)
                {
                    b.orderId = order.id;
                    await ORM.Insert(Database.GetInstance().connection, b);
                }
                this.Hide();
                dataGridView1.Refresh();

            }
            else
            {
                MessageBox.Show("Cannot create order");
                return;
            }
        }

        private bool checkProductsCapacity()
        {
            if (bindinglist.Count <= 0)
            {
                return false;
            }

            foreach (var b in bindinglist)
            {
                foreach(Product c in comboBox1.Items)
                {
                    if(c.id == b.productId && c.quantity < b.quantity)
                    {
                        return false;
                    }
                }
            }

            return true;
        }
    }
}
