﻿using projekt.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projekt.Forms
{
    public partial class EditUserForm : Form
    {
        User user = new User();
        Address address = new Address();

        public EditUserForm(User u)
        {
            user = u;
            InitializeComponent();
            Init();

            fname.Text = user.fName;
            lname.Text = user.lName;
            phone.Text = user.phone;
            email.Text = user.email;
            password.Text = user.password;
            comboBox1.SelectedIndex = user.type - 1;
      
        }
        private async void Init()
        {
            address = (await ORM.Select<Address>(Database.GetInstance().connection, "SELECT * FROM Address WHERE id = @0", user.addressId))[0];

            street.Text = address.street;
            city.Text = address.city;
            psc.Text = address.postalCode;
            country.Text = address.country;
        }

        private async void Save(object sender, EventArgs e)
        {
            if (fname.Text != "" && lname.Text != "" && password.Text != "" && phone.Text != "" && email.Text != "" && street.Text != "" && city.Text != "" && psc.Text != "" && country.Text != "")
            {
                address.street = street.Text;
                address.city = city.Text;
                address.postalCode = psc.Text;
                address.country = country.Text;

                await ORM.Update(Database.GetInstance().connection, address);

                user.fName = fname.Text;
                user.lName = lname.Text;
                user.email = email.Text;
                user.phone = phone.Text;
                user.type = comboBox1.SelectedIndex + 1;
                user.password = password.Text;

                await ORM.Update(Database.GetInstance().connection, user);

                this.Hide();
            }
        }
    }
}
