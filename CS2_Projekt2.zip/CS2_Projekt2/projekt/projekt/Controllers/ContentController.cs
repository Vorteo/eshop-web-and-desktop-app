﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using projekt.Models;
using projekt.Services;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace projekt.Controllers
{
    public class ContentController : Controller
    {
        private readonly ILogger<ContentController> _logger;

        public async void Init()
        {
            await Database.GetInstance().Connect();
        }

        public ContentController(ILogger<ContentController> logger)
        {
            _logger = logger;
            Init();
        }

        public async Task<IActionResult> GetJson()
        {
            List<Product> products = await Product.GetProducts();

            return new JsonResult(products);
        }

        public async Task<IActionResult> GetXml()
        {
            List<Product> products = await Product.GetProducts();

            MemoryStream stream = new MemoryStream();
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Product>));
            xmlSerializer.Serialize(stream, products);

            stream.Seek(0, SeekOrigin.Begin);

            return new FileStreamResult(stream, "text/xml");
        }
    }
}
