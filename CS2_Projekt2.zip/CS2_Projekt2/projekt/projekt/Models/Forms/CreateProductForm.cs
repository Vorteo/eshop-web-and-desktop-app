﻿using System.Collections.Generic;

namespace projekt.Models.Forms
{
    public class CreateProductForm
    {
        public Product product { get; set; }
        public int catId { get; set; }
    }
}
