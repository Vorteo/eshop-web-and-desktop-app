﻿namespace projekt.Models.Forms
{
    public class OrderForm
    {
        public int id { get; set; }
    }
}
