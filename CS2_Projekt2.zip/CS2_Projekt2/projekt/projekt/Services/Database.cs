﻿using Microsoft.Data.Sqlite;
using System.IO;
using System.Threading.Tasks;

namespace projekt.Services
{
    public class Database
    {
        private static Database db;
        public SqliteConnection connection { get; set; }

        public static Database GetInstance()
        {
            if (db == null)
            {
                db = new Database();
            }
            return db;
        }
        public async Task<bool> Connect()
        {
            if (db.connection != null && db.connection.State == System.Data.ConnectionState.Open)
            {
                await db.Close();
            }

            string connectionString = @"Data Source=mydb.db;";
            db.connection = new SqliteConnection(connectionString);
            await db.connection.OpenAsync();


            return true;
        }
        public async Task Close()
        {
            await db.connection.CloseAsync();
        }

        public async Task createDB()
        {
            string createScript = File.ReadAllText("db-create.sql");

            if (!File.Exists("mydb.db"))
            {
                GetInstance();
                await db.Connect();

                using (SqliteCommand command = new SqliteCommand())
                {
                    command.CommandText = createScript;
                    command.Connection = db.connection;
                    await command.ExecuteNonQueryAsync();
                }
                await db.Close();
            }
        }

    }
}
